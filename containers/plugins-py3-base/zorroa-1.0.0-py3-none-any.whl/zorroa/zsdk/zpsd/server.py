import logging
import zmq

from zorroa.zsdk.processor import Reactor
from zorroa.zsdk.executor import ProcessorExecutor

logger = logging.getLogger(__name__)


class ZpsdServer(object):
    def __init__(self, port, reactor=None):
        self.port = port
        self.socket = self.__setup_zmq_socket()

        if not reactor:
            reactor = Reactor(ZmqEventEmitter(self.socket))
        self.executor = ProcessorExecutor(reactor)

    def __setup_zmq_socket(self):
        ctx = zmq.Context()
        socket = ctx.socket(zmq.PAIR)
        socket.bind("tcp://*:{}".format(self.port))
        return socket

    def start(self):
        logging.info("Starting ZPSD on port {}".format(self.port))
        while True:
            event = self.socket.recv_json()
            try:
                self.handle_event(event)
            except Exception as e:
                logger.warning("Failed to handle event '{}', e".format(event, e))

    def stop(self):
        self.socket.close()

    def handle_event(self, event):
        etype = event["type"]
        if etype == "execute":
            obj = self.executor.execute_processor(event["payload"])
            self.socket.send_json({"event": "object", "payload": obj})
        elif etype == "teardown":
            self.executor.teardown_processor(event["payload"])


class ZmqEventEmitter(object):
    def __init__(self, socket):
        self.socket = socket

    def write(self, event):
        self.socket.send_json(event)


