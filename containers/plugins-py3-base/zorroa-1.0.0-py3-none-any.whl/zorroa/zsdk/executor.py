import sys
import json
import hashlib
import logging
import time

from zorroa.zsdk.processor import Reactor, Frame
from zorroa.zsdk.document.asset import Asset, Document
from zorroa.zsdk.exception import UnrecoverableProcessorException

logger = logging.getLogger(__name__)


class ProcessorWrapper(object):
    def __init__(self, instance, ref, reactor):
        self.instance = instance
        self.ref = ref
        self.reactor = reactor
        self.stats = {
            "process_count": 0,
            "process_error_count": 0,
            "process_total_time": 0
        }

    def init(self):
        if self.instance:
            self.instance.init()

    def process(self, frame):
        start_time = time.monotonic()
        try:
            if self.instance:
                self.instance.process(frame)
                self.reactor.emitter.write({"type": "object", "payload": frame.asset.for_json()})
            self.increment("process_count")

        except UnrecoverableProcessorException as upe:
            self.increment("process_error_count")
            self.reactor.error(frame, self["ref"]["className"],
                               upe, True, "execute", sys.exc_info()[2])
        except Exception as e:
            self.increment("process_error_count")
            self.reactor.error(frame, self.instance, e, False, "execute", sys.exc_info()[2])
        finally:
            proc_time = round(time.monotonic() - start_time, 2)
            self.increment("process_total_time", proc_time)
            self.reactor.emitter.write({"type": "final", "payload": {"total_time": proc_time}})
            logger.debug("executed %s in %0.2f seconds" % (self.ref["className"], proc_time))

    def teardown(self):
        if not self.instance:
            logger.warning("Teardown error, instance for '{}' does not exist.", self.ref)
            return
        try:
            self.instance.teardown()
            self.reactor.emitter.write({"type": "stats", "payload": self.stats})
        except Exception as e:
            self.reactor.error(None, self.instance, e, False, "teardown", sys.exc_info()[2])

    def increment(self, key, value=1):
        self.stats[key] += value


class ProcessorExecutor(object):

    def __init__(self, reactor):
        self.reactor = reactor
        self.processors = {}

    def execute_processor(self, request):
        ref = request["ref"]
        frame = Frame(Asset.from_document(Document(request["object"])))
        wrapper = self.get_processor_wrapper(ref)
        wrapper.process(frame)
        return frame.asset.for_json()

    def teardown_processor(self, request):
        ref = request["ref"]
        wrapper = self.get_processor_wrapper(ref)
        wrapper.teardown()
        key = self.get_processor_key(wrapper.ref)
        try:
            del self.processors[key]
        except KeyError:
            logger.warning("Failed to remove processor from execution cache: {}".format(ref))

    def get_processor_key(self, ref):
        sha1 = hashlib.sha256()
        sha1.update(json.dumps(ref, sort_keys=True, default=str).encode("utf-8"))
        return sha1.hexdigest()

    def get_processor_wrapper(self, ref):
        # Determine if we already have a processor instance.
        # Utilize the existing instance.
        key = self.get_processor_key(ref)
        if key not in self.processors:
            wrapper = ProcessorWrapper(self.new_processor_instance(ref), ref, self.reactor)
            wrapper.init()
            self.processors[key] = wrapper
        else:
            wrapper = self.processors[key]
        return wrapper

    def new_processor_instance(self, ref):
        """
        Construct and return an instance of the processor described by
        the given processor reference dict.

        Args:
            ref (dict): A processor reference dict
            reactor (Reactor): A process reactor instance.

        Returns:
            Processor: an instance of a Processor class.

        """
        try:
            mod_name, cls_name = ref["className"].rsplit(".", 1)
            mod_name = str(mod_name)
            cls_name = str(cls_name)
            module = __import__(mod_name, globals(), locals(), [cls_name])
            instance = getattr(module, cls_name)()
            logger.debug("Created new instance of {}".format(ref["className"]))
            return instance
        except Exception as e:
            logger.warning("Failed to create new instance of {}, {}".format(ref["className"], e))
            self.reactor.error(None, ref.get("className"), e, True, "initialize", sys.exc_info()[2])
            # Return an empty wrapper here so we can centralize the point
            # where the 'final' event is emitted.
            return None

